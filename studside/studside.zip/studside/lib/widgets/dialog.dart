import 'package:flutter/material.dart';
import '../models/mainmodel.dart';

class CustomDialog extends StatefulWidget {
  final MainModel model;
  CustomDialog(this.model);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _CustomDialogState();
  }
}

class _CustomDialogState extends State<CustomDialog> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Dialog(
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: widget.model.allPreList.length,
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  style: BorderStyle.solid,
                  color: Colors.orange,
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              children: <Widget>[
                Flexible(
                  flex: 4,
                  child: Column(
                    children: <Widget>[
                      Container(
                        child: Center(
                          child: Text(
                            widget.model.allPreList[index].itemName,
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      Container(
                        height: 20.0,
                        padding: EdgeInsets.symmetric(horizontal: 65.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Flexible(
                              flex: 3,
                              child: IconButton(
                                iconSize: 15.0,
                                padding:
                                    EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                                icon: Icon(Icons.remove),
                                onPressed: () {
                                  if (widget.model.allPreList[index].quantity >
                                      0) {
                                    setState(() {
                                      widget.model.removeQuantityPreList(index);
                                    });
                                  }
                                },
                              ),
                            ),
                            Flexible(
                              flex: 3,
                              child: Container(
                                padding:
                                    EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                                child: Text(
                                  widget.model.allPreList[index].quantity
                                      .toString(),
                                  style: TextStyle(color: Colors.orange),
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 3,
                              child: IconButton(
                                iconSize: 15.0,
                                padding:
                                    EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 0.0),
                                icon: Icon(Icons.add),
                                onPressed: () {
                                  setState(() {
                                    widget.model.addQuantityPreList(index);
                                  });
                                },
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  flex: 1,
                  child: IconButton(
                    icon: Icon(Icons.remove),
                    onPressed: () {
                      setState(() {
                        widget.model.removeItemPreList(index);
                      });
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
