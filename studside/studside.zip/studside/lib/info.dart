class UrlInfo {
  static final String host = '13.232.74.100';
  static final int port = 8000;
  static final String scheme = 'http';
  static final fullUrl = scheme + '://' + host + ':' + port.toString() + '/';
}
